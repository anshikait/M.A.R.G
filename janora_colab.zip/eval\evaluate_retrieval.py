"""Step 4 baselines. Vague rows are excluded by default (as in the plan baseline); add --include-vague to score them.  Metrics: Recall@3, Recall@10, MRR, overall and by language / noise / row type.
  python -m eval.evaluate_retrieval --split val --modes bm25                      # reproduce your 32.1% baseline first
  python -m eval.evaluate_retrieval --split val --modes bm25 dense hybrid         # GPU/Colab for BGE-M3
  python -m eval.evaluate_retrieval --split val --index split --modes bm25        # if the baseline only matches this way
Rows without a target scheme (offtopic) are not scored here."""
import argparse
import numpy as np, pandas as pd
from configs import settings as S
from src.data_prep import loaders as L
from src.retrieval.hybrid_retriever import HybridRetriever


def score(ret, q: pd.DataFrame, mode):
    ranked = ret.rank_lists(q["query"].tolist(), mode)
    pos = {s: i for i, s in enumerate(ret.df["slug"])}
    ranks = []
    for gold, lst in zip(q["slug"], ranked):
        order = [i for i, _ in lst]
        ranks.append(order.index(pos[gold]) + 1 if pos.get(gold) in order else 10**6)
    r = np.array(ranks)
    return pd.DataFrame({"hit3": r <= 3, "hit10": r <= 10, "rr": np.where(r < 10**6, 1 / r, 0.0)}, index=q.index)


def table(q, m, by):
    g = pd.concat([q[[by]], m], axis=1).groupby(by)
    t = g.agg(n=("hit3", "size"), R3=("hit3", "mean"), R10=("hit10", "mean"), MRR=("rr", "mean"))
    return t.sort_values("n", ascending=False).round(3)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="val"); ap.add_argument("--modes", nargs="+", default=["bm25"])
    ap.add_argument("--index", choices=["all", "split"], default="all"); ap.add_argument("--include-vague", action="store_true"); ap.add_argument("--model", default=None)
    a = ap.parse_args()
    docs = L.card_frame()
    if a.index == "split": docs = docs[docs.split == a.split]
    q = L.load_queries(a.split); q = q[q.slug.notna() & q.slug.isin(docs.slug)].copy()
    if not a.include_vague:                      # your plan's baseline (1,610 queries) excludes vague rows
        q = q[q.row_type != "vague"].copy()
    print(f"index={a.index} docs={len(docs)} | scored queries={len(q)}")
    ret = HybridRetriever(docs, use_dense=any(m != "bm25" for m in a.modes), model_name=a.model)
    S.RESULTS.mkdir(parents=True, exist_ok=True)
    for mode in a.modes:
        m = score(ret, q, mode)
        print(f"\n######## {mode}   Recall@3={m.hit3.mean():.3f}  Recall@10={m.hit10.mean():.3f}  MRR={m.rr.mean():.3f}")
        for by in ("language", "noise", "row_type"):
            t = table(q, m, by); print(f"\n-- by {by}\n{t.to_string()}")
            t.to_csv(S.RESULTS / f"retrieval_{a.split}_{a.index}_{mode}_by_{by}.csv")